const settings = {
  packname: 'madewith❤️;DFS',
  author: 'reddragon-dfs',
  botName: "explore md",
  botOwner: 'Reddragon-DFS', // Your name
  ownerNumber: '27634988678', //Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;

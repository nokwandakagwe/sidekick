# ꧁༒Explore-md-V1༒꧂
![Typing SVG](https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=ff0000&center=true&width=900&height=100&lines=Its%20EXPLORE-V1-MD;%20Multi-Device%20WhatsApp%20Bot;%20Developed%20By%20RED%20DRAGON)
<p align="center">
---

<div align="center">
  <img src="https://files.catbox.moe/hojgxq.jpg" width="300" style="border-radius: 20px; box-shadow: 0 0 20px #00ffff;"/>
</div>
<div align="center">

<img src="https://komarev.com/ghpvc/?username=explore-md&label=Profile+Views&color=success&style=flat-square" />
<img src="https://img.shields.io/github/forks/nomfundokagwe/Explore-md-V1?color=blue&style=yellow-square" />
<img src="https://img.shields.io/github/forks/nomfundokagwe/Explore-md-V1?color=ff00ff&style=flat-square" />
<img src="https://img.shields.io/github/repo-size/nomfundokagwe/Explore-md-V1?color=success&style=flat-square" />
<img src="https://img.shields.io/github/last-commit/nomfundokagwe/Explore-md-V1?color=yellow&style=flat-square" />
<a href="https://t.me/darknessfreenetsquad">
  <img title="Join our Discord" src="https://img.shields.io/discord/1391898062494105752?label=Discord&logo=discord&logoColor=white&style=flat-square&color=7289DA" alt="Discord">
</a>
</div>
  
----
<p align="center">
    <strong>. GET SESSION ID</strong>
    <br>
    <a href="https://explore-md-botswebpair.onrender.com/pair" target="_blank">
        <img alt="WEBSITE" src="https://img.shields.io/badge/Pair-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkred&color=darkred"/>
    </a>
</p>

<h2 align="center">🛰️ Deployment Steps</h2>

<div style="background: #000000; border: 1px solid #00ffff; border-radius: 15px; padding: 20px; box-shadow: 0 0 15px #00ffff; margin-bottom: 30px;">

  <div style="background: #111111; padding: 15px; border-radius: 10px; border-left: 4px solid #ff00ff;">
    <p style="color: #00ffff; font-size: 16px;">🚀 First, star & fork the repo using the button below:</p>
    <a href='https://github.com/nomfundokagwe/Explore-md-V1/fork' target="_blank">
      <img src='https://img.shields.io/badge/FORK_REPOSITORY-008000?style=for-the-badge&logo=github&logoColor=white&labelColor=000000'/>
    </a>
  </div>

</div>

<div style="background: #000000; border: 1px solid #ff00ff; border-radius: 15px; padding: 20px; box-shadow: 0 0 15px #ff00ff; margin-bottom: 30px;">

  <div style="background: #111111; padding: 15px; border-radius: 10px; border-left: 4px solid #00ffff;">
    <p style="color: #ff00ff; font-size: 16px;">📦 Next, deploy using your preferred method (Heroku, Railway, etc.)</p>
    <ul style="color: #ffffff; line-height: 1.6;">
      <li>📁 Clone or fork the repository</li>
      <li>⚙️ Add your <code>.config</code> variables</li>
      <li>🚀 Deploy using platform buttons or manual setup</li>
    </ul>
  </div>

</div>
  
---

## `NEW DEPLOYMENT`
NOW Deploy👇
**Option : Deploy In Panel**
 1. First You Have to Sign up on discord using web or app then click below.
2. [Sign Up On Panel](https://dashboard.katabump.com/auth/login#0ab68a) if you don’t have Already.
3. Click the button below to deploy using Panel:
   <br>
   <a href='https://dashboard.katabump.com/auth/login#0ab68a' target="_blank">
      <img alt='Deploy In Panel' src='https://img.shields.io/badge/-DEPLOY-green?style=for-the-badge&logo=Cloudflare&logoColor=white'/>
   </a>
   
## `MORE PANELS`
FREE FOR HOSTING WHATSAPP BOTS
* 
```bash
https://optiklink.com
```
```bash
bot-hosting.net
```
```bash
https://witchly.host
```
```bash
https://pylexnodes.net
```
```bash
https://Solarhosting.net
```
```bash
https://ztx.gd
```
```bash
https://netherite.io
```
```bash
https://dash.boxmineworld.com/register?ref=eAozeFoa
```
## `Pannel Supoort`
```bash
1. Fork Repository
2. If already forked then sync fork repository
3. Then click on code and click download as zip
4. Then upload script zip file to pannel
5. Unarchieve zip sile
6. Open bot folder and move all filea to container by (../)
7. Now run bot
8. After 1-2min it show you QR to scan
9. Scan The QR in Whatsapp Link Device
10. Bot Connected done now use bot 
 
```
### Additional Hosting Panels

<a href="https://account.solarhosting.cc/" target="_blank">
  <img src="https://img.shields.io/badge/Solar_Hosting-FF6B6B?style=for-the-badge&logo=server&logoColor=white" alt="Solar Hosting"/>
</a>

<a href="https://my.blare.host/" target="_blank">
  <img src="https://img.shields.io/badge/Blare_Host-4A90E2?style=for-the-badge&logo=server&logoColor=white" alt="Blare Host"/>
</a>

<a href="https://dash.witchly.host/" target="_blank">
  <img src="https://img.shields.io/badge/Witchly_Host-9B59B6?style=for-the-badge&logo=server&logoColor=white" alt="Witchly Host"/>
</a>

<a href="https://optiklink.com/" target="_blank">
  <img src="https://img.shields.io/badge/Optik_Link-2ECC71?style=for-the-badge&logo=server&logoColor=white" alt="Optik Link"/>
</a>

<a href="https://panel.sillydev.co.uk" target="_blank">
  <img src="https://img.shields.io/badge/SillyDev_Panel-E67E22?style=for-the-badge&logo=server&logoColor=white" alt="SillyDev Panel"/>
</a>

<a href="https://cloves.mypi.co/" target="_blank">
  <img src="https://img.shields.io/badge/Cloves_MyPi-3498DB?style=for-the-badge&logo=server&logoColor=white" alt="Cloves MyPi"/>
</a>

<a href="https://client.botwa.net/login" target="_blank">
  <img src="https://img.shields.io/badge/BotWA_Panel-27AE60?style=for-the-badge&logo=server&logoColor=white" alt="BotWA Panel"/>
</a>

<a href="https://netherite.io/" target="_blank">
  <img src="https://img.shields.io/badge/Netherite_Host-8E44AD?style=for-the-badge&logo=server&logoColor=white" alt="Netherite Host"/>
</a>

<a href="https://bot-hosting.net/" target="_blank">
  <img src="https://img.shields.io/badge/Bot_Hosting-E74C3C?style=for-the-badge&logo=server&logoColor=white" alt="Bot Hosting"/>
</a>

<a href="https://panel.hardy.host/auth/login" target="_blank">
  <img src="https://img.shields.io/badge/Hardy_Host-F1C40F?style=for-the-badge&logo=server&logoColor=black" alt="Hardy Host"/>
</a>

<a href="https://dashboard.katabump.com/auth/login" target="_blank">
  <img src="https://img.shields.io/badge/Katabump-D6B7D6?style=for-the-badge&logo=server&logoColor=black" alt="Katabump"/>
</a>

<a href="https://daki.cc" target="_blank">
  <img src="https://img.shields.io/badge/Daki_CC-34495E?style=for-the-badge&logo=server&logoColor=white" alt="Daki CC"/>
</a>

<a href="https://pella.app" target="_blank">
  <img src="https://img.shields.io/badge/Pella_App-16A085?style=for-the-badge&logo=server&logoColor=white" alt="Pella App"/>
</a>



---

<p align="center">
  
 7. ## DEPLOY IN TERMUX



 9. **For Ubuntu Users**
   
```
pkg update && pkg upgrade -y
```
```
pkg install proot-distro
```
```
proot-distro install ubuntu
```
```
proot-distro login ubuntu
```
```
apt update && apt upgrade -y
```
```
apt install -y webp git ffmpeg curl imagemagick
```
```
apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_20.x | bash - && apt -y install nodejs
```
```
exit
```
```
proot-distro login ubuntu
```
```
git clone https://github.com/<your gitHub Username>/---
cd ---
```
```
npm install
```
```
npm start
```

-----

**For Fedora Users**

```
pkg update && pkg upgrade -y
```
```
pkg install proot-distro
```
```
proot-distro install fedora
```
```
proot-distro login fedora
```
```
dnf update -y
```
```
sudo dnf install -y https://download1.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm
sudo dnf install -y https://download1.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-$(rpm -E %fedora).noarch.rpm
```
```
sudo dnf install -y libwebp git ffmpeg curl ImageMagick
```
```
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo dnf install -y nodejs
```
```
exit
```
```
proot-distro login fedora
```
```
git clone https://github.com/<your gitHub Username>/---
cd ---
```
```
npm install
```
```
npm start
```

----
</p>


<h2></h2>
## 🤖 BOT FEATURES

- ✅ Anti-call, anti-delete, short session
- ✅ Auto status read, auto message react
- ✅ Group + DM features
- ✅ Public/Private mode
- ✅ Secure cloud-hosting compatible
- ✅ Developer maintened: ReddragonTech

---
  ## ``Support Channel``
   
   [![WHATSAPP](https://img.shields.io/badge/Support%20Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](  https://whatsapp.com/channel/0029Vb4HUnJAjPXOWnELU82J)

<a aria-label="Join our chats" href="https://wa.me/27634988678?text=Hi!! Sibongakonke Sir, I need Your Help" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Owner%20Whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</p>
## 🛠️ HOW TO USE

```bash
# STEP 1: Fork the repo
# STEP 2: Get your session ID (use link above)
# STEP 3: Choose a host from table above
# STEP 4: Deploy and input environment variables
# STEP 5: Start the bot and enjoy powerful features
```
# 🔒 `Reminder`
Misusing the bot may result in a ban from WhatsApp. Use at your own risk.


